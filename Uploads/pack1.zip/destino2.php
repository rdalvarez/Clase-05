<HTML>
<HEAD>
<TITLE>destino2.php</TITLE>
</HEAD>
<BODY>
<?
echo "Variable \$nombre: $nombre <br>\n";
echo "Variable \$apellidos: $apellidos <br>\n"
?>
</BODY>
</HTML> 
