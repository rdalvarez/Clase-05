<HTML>
<HEAD>
<TITLE>cambiolinea.php</TITLE>
</HEAD>
<BODY>
<?
echo "Hola, \n sigo en la misma l�nea ejecutada pero no en c�digo fuente.<br>Ahora cambio de l�nea ejecutada pero continuo en la misma en el c�digo fuente."
?>
</BODY>
</HTML> 