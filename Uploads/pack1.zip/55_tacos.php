<HTML>
<HEAD>
<TITLE>55_tacos.php</TITLE>
</HEAD>
<BODY>
<?
$a=55;
$mensaje="Tengo $a a�os";
echo $mensaje //El resultado es: "Tengo 55 a�os"
?> 
</BODY>
</HTML> 