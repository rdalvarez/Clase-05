<HTML>
<HEAD>
<TITLE>array.php</TITLE>
</HEAD>
<BODY>
<?
$pais=array
(
"espana" =>array
   (
   "nombre"=>"Espa�a",
   "lengua"=>"Castellano",
   "moneda"=>"Peseta"
   ),
"francia" =>array
   (
   "nombre"=>"Francia",
   "lengua"=>"Franc�s",
   "moneda"=>"Franco"
   )
);
echo $pais["espana"]["moneda"] //Saca en pantalla: "Peseta"
?>
</BODY>
</HTML> 