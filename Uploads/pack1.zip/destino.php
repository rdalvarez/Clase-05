<HTML>
<HEAD>
<TITLE>destino.php</TITLE>
</HEAD>
<BODY>
<?
echo "Variable \$saludo: $saludo <br>\n";
echo "Variable \$texto: $texto <br>\n"
?>
</BODY>
</HTML>
