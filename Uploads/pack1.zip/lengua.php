<HTML>
<HEAD>
<TITLE>Detector de Lengua</TITLE>
</HEAD>
<BODY>
<?
//Antes de nada introducimos mensajes en forma de variables
$espanol="Hola";
$ingles="Hello";
$frances="Bonjour";

//Ahora leemos del navegador cu�l es su lengua oficial
$idioma=substr($HTTP_ACCEPT_LANGUAGE,0,2);

//Formulamos las posibilidades que se pueden dar
if ($idioma == "es")
{echo "$espanol";}
elseif ($idioma=="fr")
{echo "$frances";}
else
{echo "$ingles";}
?>
</BODY>
</HTML>
