<html>
<head>
	<title>foreach.php</title>
</head>

<body>
<?
$moneda=array("Espa�a"=> "Peseta","Francia" => "Franco","USA" => "Dolar");
Foreach ($moneda as $clave=>$valor)
{
   echo "Pais: $clave Moneda: $valor<br>";
}
?>
</body>
</html>
