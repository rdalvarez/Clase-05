<html>
<head>
	<title>while.php</title>
</head>

<body>
<?
$size=1;
While ($size<=6)
{
   echo"<font size=$size>Tama�o $size</font><br>\n";
   $size++;
}
?>
</body>
</html>
