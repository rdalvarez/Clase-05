<html>
<head>
	<title>for.php</title>
</head>

<body>
<?
For ($size=1;$size<=6;$size++)
{
   echo"<font size=$size>Tama�o $size</font><br>\n";
}
?>
</body>
</html>
