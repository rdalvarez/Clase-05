<HTML>
<HEAD>
<TITLE>perro_muerde.php</TITLE>
</HEAD>
<BODY>
<?
$cadena1="Perro";
$cadena2=" muerde";
$cadena3=$cadena1.$cadena2;
echo $cadena3 //El resultado es: "Perro muerde"
?> 
</BODY>
</HTML> 